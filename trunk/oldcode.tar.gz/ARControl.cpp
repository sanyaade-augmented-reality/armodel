#include "ARControl.hpp"

void ARControl::DrawTongs() {
  int i,j,k;
}

int AddTong(char *pname) {
  
}

void SetupControl() {
  
}
    
