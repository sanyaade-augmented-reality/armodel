#ifndef __arsetup_h__
#define __arsetup_h__

#include "framework.hpp"

class ARSetup {
public:
  ARSetup();
  float GetViewScaleFactor() {return view_scalefactor;}
  void SetViewScaleFactor(float val) {view_scalefactor=val;}

  float GetViewDistanceMin() {return view_distance_min;}
  void SetViewDistanceMin(float val) {view_distance_min=val;}

  float GetViewDistanceMax() {return view_distance_max;}
  void SetViewDistanceMax(float val) {view_distance_max=val;}

  int SetupCamera();
  string GetCParamName() {return cparam_name;}
  ARParam GetCParam() {return cparam;}
private:
  // 1.0 ARToolKit unit becomes 0.025 of my OpenGL units.
  float view_scalefactor;
  // Objects closer to the camera than this will not be displayed.
  float view_distance_min;
  // Objects further away from the camera than this will not be displayed.
  float view_distance_max;

  // Glut initializer flags
  int glutInitModes;

  // Camera setup
  string cparam_name;
  string vconf;
  ARParam cparam;
};



#endif // __arsetup_h__
