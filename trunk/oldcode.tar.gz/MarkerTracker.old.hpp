#ifndef __markertracker_h__
#define __markertracker_h__

#include "framework.hpp"

class MarkerTracker {
public:
  MarkerTracker();
  int Track(ARUint8 *dataPtr);
  int MarkerFound();
  int MarkerFound(string name);
  int InitTracker();
  int GetNumMarkersFound() {return marker_num;}
  int GetScreenPos(int index, double pos[2]);
  int GetThreshold() {return threshold;}
  int SetThreshold(int thresh) {threshold=thresh;}
private:
  // Info on markers found in video stream
  ARMarkerInfo *marker_info;
  int marker_num;
  // Pattern model information
  ObjectData_T *object;
  int object_num;
  string model_name;
  // Transformation matrix retrieval.
  double gPatt_width;
  double gPatt_centre[2];
  double gPatt_trans[3][4]; 
  int gPatt_found;
  int gPatt_id;
  // Detection settings
  int threshold;
};

#endif
