template class Helper { };
extern const int foo;
const int foo = 0;
typedef Helper HelperType;
