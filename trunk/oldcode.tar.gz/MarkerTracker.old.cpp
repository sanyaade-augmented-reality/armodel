#include "MarkerTracker.hpp"

MarkerTracker::MarkerTracker () {
  gPatt_width = 80.0;
  gPatt_centre[0] = 0.0;
  gPatt_centre[1] = 0.0;
  gPatt_found = FALSE;
  model_name = "Data/object_data2";
  threshold = 100;
}

int MarkerTracker::Track(ARUint8 *dataPtr) {
  int i,j,k;
  if(arDetectMarker(dataPtr, threshold, 
                    &marker_info, &marker_num) < 0 ) {
    return -1;
  }
  /* check for known patterns */
  for( i = 0; i < object_num; i++ ) {
    k = -1;
    for( j = 0; j < marker_num; j++ ) {
      if( object[i].id == marker_info[j].id) {
        /* you've found a pattern */
//         printf("Pattern found! %f %f\n",marker_info[j].pos[0],
//                 marker_info[j].pos[1]);
        if( k == -1 ) k = j;
        else /* make sure you have the best pattern (highest confidence factor) */
          if( marker_info[k].cf < marker_info[j].cf ) k = j;
      }
    }
    if( k == -1 ) {
      object[i].visible = 0;
      continue;
    }
		
    /* calculate the transform for each marker */
    if( object[i].visible == 0 ) {
      arGetTransMat(&marker_info[k],
                    object[i].marker_center, object[i].marker_width,
                    object[i].trans);
    }
    else {
      arGetTransMatCont(&marker_info[k], object[i].trans,
                        object[i].marker_center, object[i].marker_width,
                        object[i].trans);
    }
    object[i].pos[0]=marker_info[k].pos[0];
    object[i].pos[1]=marker_info[k].pos[1];
    object[i].visible = 1;
    //cout << "here" << endl;
  }
}

int MarkerTracker::GetScreenPos(int index, double pos[2]) {
  assert(index>=0);
  assert(index<object_num);
  if (object[index].visible) {
    pos[0] = object[index].pos[0];
    pos[1] = object[index].pos[1];
  }
}

int MarkerTracker::MarkerFound() {
  int i,j,k;
  for (i=0;i<object_num;i++) {
    //cout << object[i].visible << endl;
    if (object[i].visible) return i;
  }
  return -1;
}

int MarkerTracker::MarkerFound(string name) {
  // Is the pattern even loaded into the system?
  int i,j,k;
  int haspat=FALSE;
  for (i=0;i<object_num;i++) {
    if (strcmp(object[i].name,name.c_str())>=0) haspat=TRUE;
  }
  if (!haspat) return -1;
  // If so, has it been found?
  for(i=0;i<object_num;i++) {
    if ((strcmp(object[i].name,name.c_str())>=0) &&
        (object[i].visible)) return i;
  }
  return -1;
}

int MarkerTracker::InitTracker() {
  object = read_ObjData(model_name.c_str(), &object_num);
  if (object == NULL) return FALSE;
}
  
