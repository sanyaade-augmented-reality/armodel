#include "framework.hpp"


// ============================================================================
//	Constants
// ============================================================================

// ============================================================================
//	Global variables
// ============================================================================

// Image acquisition.
static ARUint8 *gARTImage = NULL;

// Drawing.
static ARParam gARTCparam;
static ARGL_CONTEXT_SETTINGS_REF gArglSettings = NULL;

static MarkerTracker tracker = MarkerTracker();
static ARSetup setup = ARSetup();

static double screen_position[2];
static int found;

// Something to look at, draw a rotating colour cube.
static void DrawCube(void)
{
  // Colour cube data.
  static GLuint polyList = 0;
  float fSize = 0.5f;
  long f, i;	
  const GLfloat cube_vertices [8][3] = {
    {1.0, 1.0, 1.0}, {1.0, -1.0, 1.0}, {-1.0, -1.0, 1.0}, {-1.0, 1.0, 1.0},
    {1.0, 1.0, -1.0}, {1.0, -1.0, -1.0}, {-1.0, -1.0, -1.0}, {-1.0, 1.0, -1.0} };
  const GLfloat cube_vertex_colors [8][3] = {
    {1.0, 1.0, 1.0}, {1.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 1.0, 1.0},
    {1.0, 0.0, 1.0}, {1.0, 0.0, 0.0}, {0.0, 0.0, 0.0}, {0.0, 0.0, 1.0} };
  GLint cube_num_faces = 6;
  const short cube_faces [6][4] = {
    {3, 2, 1, 0}, {2, 3, 7, 6}, {0, 1, 5, 4}, {3, 0, 4, 7}, {1, 2, 6, 5}, {4, 5, 6, 7} };
	
  if (!polyList) {
    polyList = glGenLists (1);
    glNewList(polyList, GL_COMPILE);
    glBegin (GL_QUADS);
    for (f = 0; f < cube_num_faces; f++)
      for (i = 0; i < 4; i++) {
        glColor3f (cube_vertex_colors[cube_faces[f][i]][0], cube_vertex_colors[cube_faces[f][i]][1], cube_vertex_colors[cube_faces[f][i]][2]);
        glVertex3f(cube_vertices[cube_faces[f][i]][0] * fSize, cube_vertices[cube_faces[f][i]][1] * fSize, cube_vertices[cube_faces[f][i]][2] * fSize);
      }
    glEnd ();
    glColor3f (0.0, 0.0, 0.0);
    for (f = 0; f < cube_num_faces; f++) {
      glBegin (GL_LINE_LOOP);
      for (i = 0; i < 4; i++)
        glVertex3f(cube_vertices[cube_faces[f][i]][0] * fSize, cube_vertices[cube_faces[f][i]][1] * fSize, cube_vertices[cube_faces[f][i]][2] * fSize);
      glEnd ();
    }
    glEndList ();
  }
	
  glPushMatrix(); // Save world coordinate system.
  glTranslatef(0.0, 0.0, 0.5); // Place base of cube on marker surface.
  //glDisable(GL_LIGHTING);	// Just use colours.
  glCallList(polyList);	// Draw the cube.
  glPopMatrix();	// Restore world coordinate system.
	
}

static void draw( double trans1[3][4], double trans2[3][4], int mode )
{
    double    gl_para[16];
    GLfloat   mat_ambient[]     = {0.0, 0.0, 1.0, 1.0};
    GLfloat   mat_ambient1[]    = {1.0, 0.0, 0.0, 1.0};
    GLfloat   mat_flash[]       = {0.0, 0.0, 1.0, 1.0};
    GLfloat   mat_flash1[]      = {1.0, 0.0, 0.0, 1.0};
    GLfloat   mat_flash_shiny[] = {50.0};
    GLfloat   mat_flash_shiny1[]= {50.0};
    GLfloat   light_position[]  = {100.0,-200.0,200.0,0.0};
    GLfloat   ambi[]            = {0.1, 0.1, 0.1, 0.1};
    GLfloat   lightZeroColor[]  = {0.9, 0.9, 0.9, 0.1};
    
//     argDrawMode3D();
//     argDraw3dCamera( 0, 0 );
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    
    /* load the camera transformation matrix */
    glMatrixMode(GL_MODELVIEW);
    argConvGlpara(trans1, gl_para);
    glLoadMatrixd( gl_para );
    argConvGlpara(trans2, gl_para);
    glMultMatrixd( gl_para );

    if( mode == 0 ) {
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glLightfv(GL_LIGHT0, GL_POSITION, light_position);
        glLightfv(GL_LIGHT0, GL_AMBIENT, ambi);
        glLightfv(GL_LIGHT0, GL_DIFFUSE, lightZeroColor);
        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_flash);
        glMaterialfv(GL_FRONT, GL_SHININESS, mat_flash_shiny);	
        glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    }
    else {
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glLightfv(GL_LIGHT0, GL_POSITION, light_position);
        glLightfv(GL_LIGHT0, GL_AMBIENT, ambi);
        glLightfv(GL_LIGHT0, GL_DIFFUSE, lightZeroColor);
        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_flash1);
        glMaterialfv(GL_FRONT, GL_SHININESS, mat_flash_shiny1);	
        glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient1);
    }
    glMatrixMode(GL_MODELVIEW);
    glTranslatef( 0.0, 0.0, 25.0 );
    if( !arDebug ) glutSolidCube(50.0);
     else          glutWireCube(50.0);
    glDisable( GL_LIGHTING );

    glDisable( GL_DEPTH_TEST );
}

static void Quit(void)
{
  arglCleanup(gArglSettings);
  arVideoCapStop();
  arVideoClose();
  exit(0);
}

static void Keyboard(unsigned char key, int x, int y)
{
  int mode;
  switch (key) {
  case 0x1B:  // Quit.
  case 'Q':
  case 'q':
    Quit();
    break;
  case ' ':
    break;
  default:
    break;
  }
}

static void Idle(void)
{
  static int ms_prev;
  int ms;
  float s_elapsed;
  ARUint8 *image;

  // Pointer to array holding the details of detected markers.
  ARMarkerInfo    *marker_info;
  // Count of number of markers detected.
  int             marker_num;	
  int             j, k;
	
  // Find out how long since Idle() last ran.
  ms = glutGet(GLUT_ELAPSED_TIME);
  s_elapsed = (float)(ms - ms_prev) * 0.001;
  if (s_elapsed < 0.01f) return; // Don't update more often than 100 Hz.
  ms_prev = ms;
	
  // Grab a video frame.
  if ((image = arVideoGetImage()) != NULL) {
    gARTImage = image;	// Save the fetched image.

    tracker.Track(gARTImage);

    if ((found = tracker.MarkerFound()) > -1 ) {
      tracker.GetScreenPos(found,screen_position);
      cout << "Ping "<< screen_position[0] << " " << screen_position[1] << endl;
    }

    // Tell GLUT the display has changed.
    glutPostRedisplay();
  }
}

//
//	This function is called on events when the visibility of the
//	GLUT window changes (including when it first becomes visible).
//
static void Visibility(int visible)
{
  if (visible == GLUT_VISIBLE) {
    glutIdleFunc(Idle);
  } else {
    glutIdleFunc(NULL);
  }
}

//
//	This function is called when the
//	GLUT window is resized.
//
static void Reshape(int w, int h)
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
	
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(0,w,0,h,-10,10);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  // Call through to anyone else who needs to know about window sizing here.
  if (setup.IsInit()) {
    GLdouble p[16];
    arglCameraFrustumRH(&setup.GetCParam(),
                        setup.GetViewDistanceMin(),
                        setup.GetViewDistanceMax(),
                        p);
    glMatrixMode(GL_PROJECTION);
    glLoadMatrixd(p);
  }
}

//
// This function is called when the window needs redrawing.
//
static void Display(void)
{
  int i,j;
  GLdouble p[16];
  GLdouble m[16];
	
  // Clear the buffers for new frame.
  glClearDepth( 1.0 );
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 

  arglDispImage(gARTImage, &setup.GetCParam(), 1.0, gArglSettings);
  arVideoCapNext();
  // Image data is no longer valid after calling arVideoCapNext().
  gARTImage = NULL; 

  if (0) {
    arglCameraFrustumRH(&setup.GetCParam(),
                        setup.GetViewDistanceMin(),
                        setup.GetViewDistanceMax(),
                        p);
    glMatrixMode(GL_PROJECTION);
    glLoadMatrixd(p);
  }
  glMatrixMode(GL_MODELVIEW);

  // Viewing transformation.
  glPushMatrix();
  glLoadIdentity();

  double sf = setup.GetViewScaleFactor();
  double trans[3][4];
  tracker.GetTrans(found,trans);
  arglCameraViewRH(trans, m, sf);
  glLoadMatrixd(m);

  DrawCube();
  glPopMatrix();

  if (1) {
    ARMultiMarkerInfoT *multi = tracker.GetMulti();
    glPushMatrix();
    glLoadIdentity();
    //arglCameraViewRH(multi->trans,m, sf);
    //glLoadMatrixd(m);
    //glTranslatef(0,0,1);

    for( i = 0; i < multi->marker_num; i++ ) {
      if( multi->marker[i].visible >= 0 ) {
        //glTranslatef(0,0,i);
        //glPushMatrix();
        arglCameraViewRH(multi->trans,m, sf);
        glLoadMatrixd(m);
        glTranslatef(0,0,1);
        arglCameraViewRH(multi->marker[i].trans, m, sf);

        glMultMatrixd(m);
        DrawCube();
        //glPopMatrix();
        //draw( multi->trans, multi->marker[i].trans, 0 );
      }
      else {
        if (0) {
          arglCameraViewRH(multi->marker[i].trans, m, sf);
          glPushMatrix();
          glMultMatrixd(m);
          glutSolidCube(1.);
          glPopMatrix();
          DrawCube();
        }
        //draw( multi->trans, multi->marker[i].trans, 1 );
      }
    }
    glPopMatrix();

  }
  // Lighting and geometry that moves with the camera should go here.
  // (I.e. must be specified before viewing transformations.)
  //none
	
  glutSwapBuffers();
}

int main(int argc, char **argv)
{
  // -------------------------------------------------------------------
  // Hardware setup.
  //

  glutInit(&argc, argv);
  if (!setup.SetupCamera()) {
    fprintf(stderr, "main(): Unable to set up AR camera.\n");
    exit(-1);
  }

  // -------------------------------------------------------------------
  // Library setup.
  //
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
  glutInitWindowSize(640, 480);
  glutCreateWindow(argv[0]);

  if ((gArglSettings = arglSetupForCurrentContext()) == NULL) {
    fprintf(stderr, "main(): arglSetupForCurrentContext() returned error.\n");
    exit(-1);
  }

  glEnable(GL_DEPTH_TEST);
  glDepthFunc(GL_LEQUAL);
    
  arUtilTimerReset();
		
  if (!tracker.InitTracker()) {
    fprintf(stderr, "main(): Unable to set up AR marker.\n");
    Quit();
  }
  tracker.SetThreshold(85);
  // Register GLUT event-handling callbacks.
  // NB: Idle() is registered by Visibility.
  glutDisplayFunc(Display);
  glutReshapeFunc(Reshape);
  glutVisibilityFunc(Visibility);
  glutKeyboardFunc(Keyboard);
	
  arFittingMode   = AR_FITTING_TO_IDEAL;
  if (!setup.StartCamera()) {
    fprintf(stderr, "main(): Unable to start AR camera.\n");
    exit(-1);
  }
  glutMainLoop();

  return (0);
}
