#ifndef __framework_h__
#define __framework_h__


#endif // __framework_h__
